/**
 * Cat Study Lab - Backend Server
 * Created by Kelda Maitland
 */

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'catstudylab-secret-kelda-maitland-2024';

// ─── App Metadata (hardcoded into backend) ──────────────────────────────────
const APP_META = {
  name: 'Cat Study Lab',
  creator: 'Kelda Maitland',
  footer: 'Created by Kelda Maitland',
  version: '1.0.0'
};

// ─── In-Memory Data Store ────────────────────────────────────────────────────
const db = {
  users: [],
  flashcardDecks: {},   // userId -> [deck]
  notes: {},            // userId -> [note]
  timerSessions: {},    // userId -> [session]
  studyGoals: {}        // userId -> [goal]
};

// ─── Middleware ──────────────────────────────────────────────────────────────
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());

// Serve React build in production
app.use(express.static(path.join(__dirname, '../client/build')));

// ─── Auth Middleware ─────────────────────────────────────────────────────────
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// ─── App Meta Route (returns creator info to frontend) ───────────────────────
app.get('/api/meta', (req, res) => {
  res.json(APP_META);
});

// ─── Auth Routes ─────────────────────────────────────────────────────────────
app.post('/api/auth/register', async (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password)
    return res.status(400).json({ error: 'All fields required' });

  if (db.users.find(u => u.email === email))
    return res.status(400).json({ error: 'Email already registered' });

  const hashedPassword = await bcrypt.hash(password, 10);
  const user = { id: uuidv4(), username, email, hashedPassword, createdAt: new Date().toISOString() };
  db.users.push(user);

  // Init user data stores
  db.flashcardDecks[user.id] = [];
  db.notes[user.id] = [];
  db.timerSessions[user.id] = [];
  db.studyGoals[user.id] = [];

  const token = jwt.sign({ id: user.id, username, email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username, email } });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = db.users.find(u => u.email === email);
  if (!user) return res.status(400).json({ error: 'Invalid credentials' });

  const valid = await bcrypt.compare(password, user.hashedPassword);
  if (!valid) return res.status(400).json({ error: 'Invalid credentials' });

  const token = jwt.sign({ id: user.id, username: user.username, email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username: user.username, email } });
});

app.get('/api/auth/me', authMiddleware, (req, res) => {
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ id: user.id, username: user.username, email: user.email });
});

// ─── Flashcard Routes ─────────────────────────────────────────────────────────
app.get('/api/flashcards', authMiddleware, (req, res) => {
  res.json(db.flashcardDecks[req.user.id] || []);
});

app.post('/api/flashcards/deck', authMiddleware, (req, res) => {
  const { name, emoji } = req.body;
  if (!name) return res.status(400).json({ error: 'Deck name required' });
  const deck = { id: uuidv4(), name, emoji: emoji || '📚', cards: [], createdAt: new Date().toISOString() };
  db.flashcardDecks[req.user.id].push(deck);
  res.json(deck);
});

app.post('/api/flashcards/deck/:deckId/card', authMiddleware, (req, res) => {
  const { front, back } = req.body;
  const decks = db.flashcardDecks[req.user.id];
  const deck = decks?.find(d => d.id === req.params.deckId);
  if (!deck) return res.status(404).json({ error: 'Deck not found' });
  const card = { id: uuidv4(), front, back, mastered: false, createdAt: new Date().toISOString() };
  deck.cards.push(card);
  res.json(card);
});

app.patch('/api/flashcards/deck/:deckId/card/:cardId', authMiddleware, (req, res) => {
  const decks = db.flashcardDecks[req.user.id];
  const deck = decks?.find(d => d.id === req.params.deckId);
  if (!deck) return res.status(404).json({ error: 'Deck not found' });
  const card = deck.cards.find(c => c.id === req.params.cardId);
  if (!card) return res.status(404).json({ error: 'Card not found' });
  Object.assign(card, req.body);
  res.json(card);
});

app.delete('/api/flashcards/deck/:deckId', authMiddleware, (req, res) => {
  const decks = db.flashcardDecks[req.user.id];
  db.flashcardDecks[req.user.id] = decks.filter(d => d.id !== req.params.deckId);
  res.json({ success: true });
});

// ─── Notes Routes ─────────────────────────────────────────────────────────────
app.get('/api/notes', authMiddleware, (req, res) => {
  res.json(db.notes[req.user.id] || []);
});

app.post('/api/notes', authMiddleware, (req, res) => {
  const { title, content, color } = req.body;
  const note = { id: uuidv4(), title: title || 'Untitled', content: content || '', color: color || '#fef9c3', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  db.notes[req.user.id].push(note);
  res.json(note);
});

app.patch('/api/notes/:noteId', authMiddleware, (req, res) => {
  const notes = db.notes[req.user.id];
  const note = notes?.find(n => n.id === req.params.noteId);
  if (!note) return res.status(404).json({ error: 'Note not found' });
  Object.assign(note, req.body, { updatedAt: new Date().toISOString() });
  res.json(note);
});

app.delete('/api/notes/:noteId', authMiddleware, (req, res) => {
  db.notes[req.user.id] = db.notes[req.user.id].filter(n => n.id !== req.params.noteId);
  res.json({ success: true });
});

// ─── Timer / Pomodoro Routes ──────────────────────────────────────────────────
app.post('/api/timer/session', authMiddleware, (req, res) => {
  const { duration, type, subject } = req.body; // type: 'focus' | 'break'
  const session = { id: uuidv4(), duration, type, subject: subject || '', completedAt: new Date().toISOString() };
  if (!db.timerSessions[req.user.id]) db.timerSessions[req.user.id] = [];
  db.timerSessions[req.user.id].push(session);
  res.json(session);
});

app.get('/api/timer/sessions', authMiddleware, (req, res) => {
  res.json(db.timerSessions[req.user.id] || []);
});

// ─── Study Goals Routes ───────────────────────────────────────────────────────
app.get('/api/goals', authMiddleware, (req, res) => {
  res.json(db.studyGoals[req.user.id] || []);
});

app.post('/api/goals', authMiddleware, (req, res) => {
  const { text, targetDate } = req.body;
  const goal = { id: uuidv4(), text, targetDate, completed: false, createdAt: new Date().toISOString() };
  db.studyGoals[req.user.id].push(goal);
  res.json(goal);
});

app.patch('/api/goals/:goalId', authMiddleware, (req, res) => {
  const goals = db.studyGoals[req.user.id];
  const goal = goals?.find(g => g.id === req.params.goalId);
  if (!goal) return res.status(404).json({ error: 'Goal not found' });
  Object.assign(goal, req.body);
  res.json(goal);
});

app.delete('/api/goals/:goalId', authMiddleware, (req, res) => {
  db.studyGoals[req.user.id] = db.studyGoals[req.user.id].filter(g => g.id !== req.params.goalId);
  res.json({ success: true });
});

// ─── Dashboard Stats ──────────────────────────────────────────────────────────
app.get('/api/dashboard', authMiddleware, (req, res) => {
  const uid = req.user.id;
  const sessions = db.timerSessions[uid] || [];
  const totalFocusMinutes = sessions
    .filter(s => s.type === 'focus')
    .reduce((acc, s) => acc + Math.floor(s.duration / 60), 0);

  const decks = db.flashcardDecks[uid] || [];
  const totalCards = decks.reduce((acc, d) => acc + d.cards.length, 0);
  const masteredCards = decks.reduce((acc, d) => acc + d.cards.filter(c => c.mastered).length, 0);

  const goals = db.studyGoals[uid] || [];
  const completedGoals = goals.filter(g => g.completed).length;

  res.json({
    totalFocusMinutes,
    totalSessions: sessions.filter(s => s.type === 'focus').length,
    totalDecks: decks.length,
    totalCards,
    masteredCards,
    totalGoals: goals.length,
    completedGoals,
    totalNotes: (db.notes[uid] || []).length,
    appMeta: APP_META
  });
});

// ─── Catch-all: serve React ───────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/build/index.html'));
});

app.listen(PORT, () => {
  console.log(`🐱 Cat Study Lab server running on port ${PORT}`);
  console.log(`   Created by ${APP_META.creator}`);
});
