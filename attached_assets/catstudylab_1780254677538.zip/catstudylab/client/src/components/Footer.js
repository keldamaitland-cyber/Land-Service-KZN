import React, { useEffect, useState } from 'react';

// Creator credit is also enforced from the backend /api/meta endpoint
const CREATOR = 'Kelda Maitland';

export default function Footer() {
  const [meta, setMeta] = useState(null);

  useEffect(() => {
    fetch('/api/meta')
      .then(r => r.json())
      .then(setMeta)
      .catch(() => {});
  }, []);

  const creatorText = meta?.creator || CREATOR;

  return (
    <footer style={{
      textAlign: 'center',
      padding: '18px 20px',
      color: '#9ca3af',
      fontSize: '13px',
      fontWeight: 600,
      borderTop: '1.5px solid #e9d5ff',
      background: 'white',
      marginTop: 'auto'
    }}>
      <span>🐱 Cat Study Lab</span>
      <span style={{ margin: '0 10px', color: '#d8b4fe' }}>•</span>
      <span>Created by <strong style={{ color: '#7c3aed' }}>{creatorText}</strong></span>
    </footer>
  );
}
