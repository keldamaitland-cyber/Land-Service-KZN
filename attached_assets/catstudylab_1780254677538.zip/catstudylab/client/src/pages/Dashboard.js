import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Dashboard({ setTab }) {
  const { user, authFetch } = useAuth();
  const [stats, setStats] = useState(null);

  useEffect(() => {
    authFetch('/api/dashboard').then(r => r.json()).then(setStats).catch(() => {});
  }, []);

  const statCards = stats ? [
    { emoji: '⏱️', label: 'Focus Minutes', value: stats.totalFocusMinutes, color: '#7c3aed', bg: '#f5f3ff' },
    { emoji: '🃏', label: 'Flashcard Decks', value: stats.totalDecks, color: '#ec4899', bg: '#fdf2f8' },
    { emoji: '✅', label: 'Cards Mastered', value: `${stats.masteredCards}/${stats.totalCards}`, color: '#10b981', bg: '#f0fdf4' },
    { emoji: '🎯', label: 'Goals Done', value: `${stats.completedGoals}/${stats.totalGoals}`, color: '#f59e0b', bg: '#fffbeb' },
    { emoji: '📝', label: 'Notes', value: stats.totalNotes, color: '#6366f1', bg: '#eef2ff' },
    { emoji: '🔥', label: 'Study Sessions', value: stats.totalSessions, color: '#ef4444', bg: '#fff1f2' },
  ] : [];

  const quickLinks = [
    { tab: 'flashcards', emoji: '🃏', label: 'Study Flashcards', desc: 'Quiz yourself with your decks' },
    { tab: 'timer', emoji: '⏱️', label: 'Start Pomodoro', desc: 'Focus with timed sessions' },
    { tab: 'notes', emoji: '📝', label: 'Open Notes', desc: 'Jot down your study notes' },
    { tab: 'goals', emoji: '🎯', label: 'View Goals', desc: 'Track your study goals' },
  ];

  return (
    <div style={{ padding: '28px 24px', maxWidth: 900, margin: '0 auto' }}>
      {/* Welcome */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 26, fontWeight: 800, color: '#5b21b6' }}>
          👋 Welcome back, {user?.username}!
        </h1>
        <p style={{ color: '#6b7280', marginTop: 4 }}>Ready to study? Here's your overview.</p>
      </div>

      {/* Stats Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 14, marginBottom: 32 }}>
        {stats ? statCards.map(s => (
          <div key={s.label} className="card" style={{ padding: '16px 14px', background: s.bg, border: `1.5px solid ${s.color}22` }}>
            <div style={{ fontSize: 28, marginBottom: 6 }}>{s.emoji}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: s.color }}>{s.value}</div>
            <div style={{ fontSize: 12, color: '#6b7280', fontWeight: 600 }}>{s.label}</div>
          </div>
        )) : Array(6).fill(0).map((_, i) => (
          <div key={i} className="card" style={{ padding: '16px 14px', height: 90, background: '#f3f4f6', animation: 'pulse 1.5s infinite' }} />
        ))}
      </div>

      {/* Quick Links */}
      <h2 style={{ fontSize: 18, fontWeight: 800, color: '#5b21b6', marginBottom: 14 }}>🚀 Quick Start</h2>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 14 }}>
        {quickLinks.map(l => (
          <button key={l.tab} onClick={() => setTab(l.tab)} className="card" style={{
            padding: '18px 16px', textAlign: 'left', border: '1.5px solid #e9d5ff',
            background: 'white', cursor: 'pointer', transition: 'transform 0.15s, box-shadow 0.15s'
          }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = '0 8px 24px rgba(124,58,237,0.15)'; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = ''; }}>
            <div style={{ fontSize: 30, marginBottom: 8 }}>{l.emoji}</div>
            <div style={{ fontWeight: 800, color: '#5b21b6', marginBottom: 4 }}>{l.label}</div>
            <div style={{ fontSize: 13, color: '#6b7280' }}>{l.desc}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
