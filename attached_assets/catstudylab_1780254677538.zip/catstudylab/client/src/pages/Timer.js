import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';

const PRESETS = [
  { label: '25 / 5', focus: 25, breakTime: 5, desc: 'Classic Pomodoro' },
  { label: '50 / 10', focus: 50, breakTime: 10, desc: 'Long Focus' },
  { label: '15 / 3', focus: 15, breakTime: 3, desc: 'Short Sprint' },
];

export default function Timer() {
  const { authFetch } = useAuth();
  const [preset, setPreset] = useState(PRESETS[0]);
  const [phase, setPhase] = useState('focus'); // 'focus' | 'break'
  const [seconds, setSeconds] = useState(PRESETS[0].focus * 60);
  const [running, setRunning] = useState(false);
  const [sessions, setSessions] = useState([]);
  const [subject, setSubject] = useState('');
  const [completedToday, setCompletedToday] = useState(0);
  const intervalRef = useRef(null);

  useEffect(() => {
    authFetch('/api/timer/sessions').then(r => r.json()).then(s => {
      setSessions(s || []);
      const today = new Date().toDateString();
      setCompletedToday(s.filter(x => x.type === 'focus' && new Date(x.completedAt).toDateString() === today).length);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSeconds(s => {
          if (s <= 1) {
            clearInterval(intervalRef.current);
            handleComplete();
            return 0;
          }
          return s - 1;
        });
      }, 1000);
    } else {
      clearInterval(intervalRef.current);
    }
    return () => clearInterval(intervalRef.current);
  }, [running, phase]);

  const handleComplete = async () => {
    setRunning(false);
    const duration = (phase === 'focus' ? preset.focus : preset.breakTime) * 60;
    await authFetch('/api/timer/session', {
      method: 'POST',
      body: JSON.stringify({ duration, type: phase, subject })
    });
    if (phase === 'focus') setCompletedToday(n => n + 1);
    // Switch phase
    const nextPhase = phase === 'focus' ? 'break' : 'focus';
    setPhase(nextPhase);
    setSeconds((nextPhase === 'focus' ? preset.focus : preset.breakTime) * 60);
  };

  const reset = () => {
    setRunning(false);
    setPhase('focus');
    setSeconds(preset.focus * 60);
  };

  const selectPreset = (p) => {
    setPreset(p); setRunning(false); setPhase('focus'); setSeconds(p.focus * 60);
  };

  const mins = String(Math.floor(seconds / 60)).padStart(2, '0');
  const secs = String(seconds % 60).padStart(2, '0');
  const total = (phase === 'focus' ? preset.focus : preset.breakTime) * 60;
  const progress = 1 - seconds / total;
  const circumference = 2 * Math.PI * 90;

  return (
    <div style={{ padding: 24, maxWidth: 680, margin: '0 auto' }}>
      <h1 style={{ fontSize: 24, fontWeight: 800, color: '#5b21b6', marginBottom: 24 }}>⏱️ Study Timer</h1>

      {/* Presets */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 24, flexWrap: 'wrap' }}>
        {PRESETS.map(p => (
          <button key={p.label} onClick={() => selectPreset(p)} style={{
            padding: '8px 16px', borderRadius: 10, border: '2px solid',
            borderColor: preset.label === p.label ? '#7c3aed' : '#e9d5ff',
            background: preset.label === p.label ? '#f5f3ff' : 'white',
            fontWeight: 700, color: preset.label === p.label ? '#5b21b6' : '#6b7280', fontSize: 14
          }}>
            {p.label} <span style={{ fontSize: 11, fontWeight: 400 }}>· {p.desc}</span>
          </button>
        ))}
      </div>

      {/* Subject */}
      <div style={{ marginBottom: 24 }}>
        <label>What are you studying? (optional)</label>
        <input type="text" value={subject} onChange={e => setSubject(e.target.value)} placeholder="e.g. Biology, Maths, History..." />
      </div>

      {/* Timer Circle */}
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 24 }}>
        <div style={{ position: 'relative', width: 220, height: 220 }}>
          <svg width={220} height={220} style={{ transform: 'rotate(-90deg)' }}>
            <circle cx={110} cy={110} r={90} fill="none" stroke="#e9d5ff" strokeWidth={10} />
            <circle cx={110} cy={110} r={90} fill="none"
              stroke={phase === 'focus' ? '#7c3aed' : '#10b981'}
              strokeWidth={10}
              strokeDasharray={circumference}
              strokeDashoffset={circumference * (1 - progress)}
              strokeLinecap="round"
              style={{ transition: 'stroke-dashoffset 1s linear' }}
            />
          </svg>
          <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: phase === 'focus' ? '#7c3aed' : '#10b981', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 4 }}>
              {phase === 'focus' ? '🐱 Focus' : '☕ Break'}
            </div>
            <div style={{ fontSize: 46, fontWeight: 800, color: '#1e1b4b', letterSpacing: -1 }}>{mins}:{secs}</div>
            <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 2 }}>🔥 {completedToday} today</div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginBottom: 32 }}>
        <button className="btn-primary" onClick={() => setRunning(r => !r)} style={{ padding: '12px 32px', fontSize: 16 }}>
          {running ? '⏸ Pause' : '▶ Start'}
        </button>
        <button className="btn-secondary" onClick={reset}>↺ Reset</button>
        {running || seconds < total ? (
          <button onClick={handleComplete} style={{ padding: '12px 20px', borderRadius: 10, border: 'none', background: '#f0fdf4', color: '#059669', fontWeight: 700 }}>
            ✓ Done Early
          </button>
        ) : null}
      </div>

      {/* Session Log */}
      <h2 style={{ fontSize: 16, fontWeight: 800, color: '#5b21b6', marginBottom: 12 }}>📋 Recent Sessions</h2>
      {sessions.length === 0 ? (
        <p style={{ color: '#9ca3af', fontSize: 14 }}>No sessions yet — start your first timer!</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[...sessions].reverse().slice(0, 8).map(s => (
            <div key={s.id} className="card" style={{ padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <span style={{ fontSize: 14, fontWeight: 700, color: s.type === 'focus' ? '#5b21b6' : '#059669' }}>
                  {s.type === 'focus' ? '🐱 Focus' : '☕ Break'}
                </span>
                {s.subject && <span style={{ fontSize: 13, color: '#6b7280', marginLeft: 8 }}>· {s.subject}</span>}
              </div>
              <div style={{ fontSize: 13, color: '#9ca3af' }}>
                {Math.floor(s.duration / 60)} min · {new Date(s.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
