import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Flashcards() {
  const { authFetch } = useAuth();
  const [decks, setDecks] = useState([]);
  const [activeDeck, setActiveDeck] = useState(null);
  const [studyMode, setStudyMode] = useState(false);
  const [studyIndex, setStudyIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [showNewDeck, setShowNewDeck] = useState(false);
  const [showNewCard, setShowNewCard] = useState(false);
  const [deckForm, setDeckForm] = useState({ name: '', emoji: '📚' });
  const [cardForm, setCardForm] = useState({ front: '', back: '' });

  const load = () => authFetch('/api/flashcards').then(r => r.json()).then(setDecks).catch(() => {});
  useEffect(() => { load(); }, []);

  const createDeck = async e => {
    e.preventDefault();
    await authFetch('/api/flashcards/deck', { method: 'POST', body: JSON.stringify(deckForm) });
    setDeckForm({ name: '', emoji: '📚' }); setShowNewDeck(false); load();
  };

  const createCard = async e => {
    e.preventDefault();
    await authFetch(`/api/flashcards/deck/${activeDeck.id}/card`, { method: 'POST', body: JSON.stringify(cardForm) });
    setCardForm({ front: '', back: '' }); setShowNewCard(false); load();
    setActiveDeck(prev => {
      const updated = decks.find(d => d.id === prev.id);
      return updated || prev;
    });
  };

  const toggleMaster = async (card) => {
    await authFetch(`/api/flashcards/deck/${activeDeck.id}/card/${card.id}`, {
      method: 'PATCH', body: JSON.stringify({ mastered: !card.mastered })
    });
    load();
  };

  const deleteDeck = async (id) => {
    await authFetch(`/api/flashcards/deck/${id}`, { method: 'DELETE' });
    setActiveDeck(null); load();
  };

  // Sync activeDeck from decks list
  useEffect(() => {
    if (activeDeck) {
      const updated = decks.find(d => d.id === activeDeck.id);
      if (updated) setActiveDeck(updated);
    }
  }, [decks]);

  const deckView = activeDeck;
  const cards = deckView?.cards || [];

  if (studyMode && deckView) {
    const card = cards[studyIndex];
    return (
      <div style={{ padding: 24, maxWidth: 600, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <button className="btn-secondary" onClick={() => { setStudyMode(false); setStudyIndex(0); setFlipped(false); }}>← Back</button>
          <span style={{ fontWeight: 700, color: '#6b7280' }}>{studyIndex + 1} / {cards.length}</span>
        </div>
        <div onClick={() => setFlipped(f => !f)} style={{
          cursor: 'pointer', minHeight: 220, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: flipped ? 'linear-gradient(135deg, #5b21b6, #7c3aed)' : 'white',
          color: flipped ? 'white' : '#1e1b4b',
          borderRadius: 20, boxShadow: '0 8px 32px rgba(124,58,237,0.18)',
          border: '2px solid #a78bfa', padding: 32, textAlign: 'center',
          transition: 'background 0.3s, color 0.3s', fontSize: 20, fontWeight: 700
        }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, opacity: 0.6, marginBottom: 12 }}>{flipped ? 'ANSWER' : 'QUESTION — tap to flip'}</div>
            {flipped ? card.back : card.front}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 20, justifyContent: 'center', flexWrap: 'wrap' }}>
          <button className="btn-secondary" disabled={studyIndex === 0} onClick={() => { setStudyIndex(i => i - 1); setFlipped(false); }}>← Prev</button>
          <button onClick={() => toggleMaster(card)} style={{
            padding: '10px 18px', borderRadius: 10, border: 'none', fontWeight: 700,
            background: card.mastered ? '#d1fae5' : '#f3f4f6', color: card.mastered ? '#059669' : '#6b7280'
          }}>{card.mastered ? '✅ Mastered' : '⬜ Mark Mastered'}</button>
          <button className="btn-primary" disabled={studyIndex === cards.length - 1} onClick={() => { setStudyIndex(i => i + 1); setFlipped(false); }}>Next →</button>
        </div>
      </div>
    );
  }

  if (deckView) {
    return (
      <div style={{ padding: 24, maxWidth: 800, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 10 }}>
          <div>
            <button className="btn-secondary" style={{ marginRight: 10 }} onClick={() => setActiveDeck(null)}>← Decks</button>
            <span style={{ fontSize: 22, fontWeight: 800, color: '#5b21b6' }}>{deckView.emoji} {deckView.name}</span>
            <span style={{ marginLeft: 10, color: '#9ca3af', fontSize: 14 }}>{cards.length} cards</span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button className="btn-primary" disabled={cards.length === 0} onClick={() => { setStudyMode(true); setStudyIndex(0); setFlipped(false); }}>▶ Study</button>
            <button className="btn-secondary" onClick={() => setShowNewCard(true)}>+ Add Card</button>
            <button className="btn-danger" onClick={() => deleteDeck(deckView.id)}>🗑</button>
          </div>
        </div>
        {cards.length === 0 ? (
          <div className="empty-state"><span className="emoji">🃏</span><h3>No cards yet</h3><p>Add your first card to get started!</p></div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 14 }}>
            {cards.map(c => (
              <div key={c.id} className="card" style={{ padding: 16, borderLeft: `4px solid ${c.mastered ? '#10b981' : '#a78bfa'}` }}>
                <div style={{ fontWeight: 700, marginBottom: 8, color: '#1e1b4b' }}>{c.front}</div>
                <div style={{ fontSize: 13, color: '#6b7280', borderTop: '1px solid #f3f4f6', paddingTop: 8, marginTop: 8 }}>{c.back}</div>
                <button onClick={() => toggleMaster(c)} style={{ marginTop: 10, fontSize: 12, padding: '4px 10px', borderRadius: 6, border: 'none', fontWeight: 700, background: c.mastered ? '#d1fae5' : '#f3f4f6', color: c.mastered ? '#059669' : '#9ca3af' }}>
                  {c.mastered ? '✅ Mastered' : '⬜ Mastered'}
                </button>
              </div>
            ))}
          </div>
        )}

        {showNewCard && (
          <div className="modal-overlay" onClick={() => setShowNewCard(false)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <h2>➕ New Card</h2>
              <form onSubmit={createCard}>
                <div style={{ marginBottom: 14 }}><label>Front (Question)</label><textarea name="front" rows={3} value={cardForm.front} onChange={e => setCardForm(f => ({ ...f, front: e.target.value }))} required /></div>
                <div style={{ marginBottom: 20 }}><label>Back (Answer)</label><textarea name="back" rows={3} value={cardForm.back} onChange={e => setCardForm(f => ({ ...f, back: e.target.value }))} required /></div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button className="btn-primary" type="submit">Add Card</button>
                  <button className="btn-secondary" type="button" onClick={() => setShowNewCard(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 800, color: '#5b21b6' }}>🃏 Flashcard Decks</h1>
        <button className="btn-primary" onClick={() => setShowNewDeck(true)}>+ New Deck</button>
      </div>

      {decks.length === 0 ? (
        <div className="empty-state"><span className="emoji">🃏</span><h3>No decks yet</h3><p>Create a deck to start studying!</p></div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 16 }}>
          {decks.map(d => (
            <button key={d.id} className="card" onClick={() => setActiveDeck(d)} style={{
              padding: '20px 18px', textAlign: 'left', cursor: 'pointer', border: '1.5px solid #e9d5ff',
              background: 'white', transition: 'transform 0.15s'
            }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-2px)'}
              onMouseLeave={e => e.currentTarget.style.transform = ''}>
              <div style={{ fontSize: 36, marginBottom: 10 }}>{d.emoji}</div>
              <div style={{ fontWeight: 800, color: '#5b21b6', marginBottom: 4 }}>{d.name}</div>
              <div style={{ fontSize: 13, color: '#9ca3af' }}>{d.cards.length} cards · {d.cards.filter(c => c.mastered).length} mastered</div>
            </button>
          ))}
        </div>
      )}

      {showNewDeck && (
        <div className="modal-overlay" onClick={() => setShowNewDeck(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h2>📚 New Deck</h2>
            <form onSubmit={createDeck}>
              <div style={{ marginBottom: 14 }}><label>Deck Name</label><input type="text" value={deckForm.name} onChange={e => setDeckForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Biology Chapter 3" required /></div>
              <div style={{ marginBottom: 20 }}>
                <label>Emoji</label>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 6 }}>
                  {['📚', '🧪', '🔬', '📐', '🎨', '🌍', '💻', '🏛', '🎵', '⚡'].map(em => (
                    <button key={em} type="button" onClick={() => setDeckForm(f => ({ ...f, emoji: em }))} style={{
                      fontSize: 22, padding: '6px 10px', borderRadius: 8, border: '2px solid',
                      borderColor: deckForm.emoji === em ? '#7c3aed' : '#e9d5ff', background: deckForm.emoji === em ? '#f5f3ff' : 'white'
                    }}>{em}</button>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button className="btn-primary" type="submit">Create Deck</button>
                <button className="btn-secondary" type="button" onClick={() => setShowNewDeck(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
