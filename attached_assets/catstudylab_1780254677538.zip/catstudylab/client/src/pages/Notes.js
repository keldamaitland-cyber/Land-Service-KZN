import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';

const COLORS = ['#fef9c3', '#fce7f3', '#ede9fe', '#d1fae5', '#dbeafe', '#fee2e2'];

export default function Notes() {
  const { authFetch } = useAuth();
  const [notes, setNotes] = useState([]);
  const [editing, setEditing] = useState(null); // note id or 'new'
  const [form, setForm] = useState({ title: '', content: '', color: COLORS[0] });

  const load = () => authFetch('/api/notes').then(r => r.json()).then(setNotes).catch(() => {});
  useEffect(() => { load(); }, []);

  const openNew = () => { setForm({ title: '', content: '', color: COLORS[0] }); setEditing('new'); };
  const openEdit = (n) => { setForm({ title: n.title, content: n.content, color: n.color }); setEditing(n.id); };

  const save = async () => {
    if (editing === 'new') {
      await authFetch('/api/notes', { method: 'POST', body: JSON.stringify(form) });
    } else {
      await authFetch(`/api/notes/${editing}`, { method: 'PATCH', body: JSON.stringify(form) });
    }
    setEditing(null); load();
  };

  const del = async (id) => {
    await authFetch(`/api/notes/${id}`, { method: 'DELETE' });
    load();
  };

  if (editing !== null) {
    return (
      <div style={{ padding: 24, maxWidth: 700, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <button className="btn-secondary" onClick={() => setEditing(null)}>← Back</button>
          <button className="btn-primary" onClick={save}>💾 Save</button>
        </div>
        {/* Color picker */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          {COLORS.map(c => (
            <button key={c} onClick={() => setForm(f => ({ ...f, color: c }))} style={{
              width: 28, height: 28, borderRadius: '50%', background: c, border: `3px solid ${form.color === c ? '#7c3aed' : 'transparent'}`, cursor: 'pointer'
            }} />
          ))}
        </div>
        <div style={{ background: form.color, borderRadius: 16, padding: 24, boxShadow: '0 4px 24px rgba(124,58,237,0.08)', border: '1.5px solid #e9d5ff' }}>
          <input
            style={{ fontSize: 22, fontWeight: 800, border: 'none', background: 'transparent', outline: 'none', width: '100%', color: '#1e1b4b', marginBottom: 16 }}
            placeholder="Note title..."
            value={form.title}
            onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
          />
          <textarea
            style={{ border: 'none', background: 'transparent', outline: 'none', width: '100%', minHeight: 300, resize: 'vertical', fontSize: 15, lineHeight: 1.7, color: '#374151' }}
            placeholder="Start writing..."
            value={form.content}
            onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
          />
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 800, color: '#5b21b6' }}>📝 Notes</h1>
        <button className="btn-primary" onClick={openNew}>+ New Note</button>
      </div>

      {notes.length === 0 ? (
        <div className="empty-state"><span className="emoji">📝</span><h3>No notes yet</h3><p>Capture your study thoughts!</p></div>
      ) : (
        <div style={{ columns: 'auto 220px', gap: 16 }}>
          {notes.map(n => (
            <div key={n.id} style={{ breakInside: 'avoid', marginBottom: 16, background: n.color, borderRadius: 14, padding: '16px 18px', border: '1.5px solid #e9d5ff', cursor: 'pointer', boxShadow: '0 2px 12px rgba(124,58,237,0.07)' }}
              onClick={() => openEdit(n)}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <h3 style={{ fontWeight: 800, fontSize: 16, color: '#1e1b4b', flex: 1 }}>{n.title}</h3>
                <button className="btn-danger" style={{ padding: '3px 8px', fontSize: 12, marginLeft: 8 }} onClick={e => { e.stopPropagation(); del(n.id); }}>🗑</button>
              </div>
              <p style={{ fontSize: 13, color: '#6b7280', lineHeight: 1.6, maxHeight: 80, overflow: 'hidden' }}>{n.content}</p>
              <p style={{ fontSize: 11, color: '#9ca3af', marginTop: 10 }}>{new Date(n.updatedAt).toLocaleDateString()}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
