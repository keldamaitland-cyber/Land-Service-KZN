import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import Footer from '../components/Footer';

export default function AuthPage() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const submit = async e => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      if (mode === 'login') await login(form.email, form.password);
      else await register(form.username, form.email, form.password);
    } catch (err) {
      setError(err.message);
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: 'linear-gradient(135deg, #f5f3ff 0%, #fce7f3 100%)' }}>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 20px' }}>
        <div className="card" style={{ width: '100%', maxWidth: 420, padding: 40 }}>
          {/* Logo */}
          <div style={{ textAlign: 'center', marginBottom: 32 }}>
            <div style={{ fontSize: 64, marginBottom: 8 }}>🐱</div>
            <h1 style={{ fontSize: 28, fontWeight: 800, color: '#5b21b6' }}>Cat Study Lab</h1>
            <p style={{ color: '#9ca3af', marginTop: 4, fontSize: 14 }}>Your purrfect study companion</p>
          </div>

          {/* Toggle */}
          <div style={{ display: 'flex', background: '#f5f3ff', borderRadius: 10, padding: 4, marginBottom: 24 }}>
            {['login', 'register'].map(m => (
              <button key={m} onClick={() => setMode(m)} style={{
                flex: 1, padding: '8px', border: 'none', borderRadius: 8,
                fontWeight: 700, fontSize: 14, transition: 'all 0.2s',
                background: mode === m ? '#7c3aed' : 'transparent',
                color: mode === m ? 'white' : '#6b7280'
              }}>
                {m === 'login' ? 'Sign In' : 'Sign Up'}
              </button>
            ))}
          </div>

          {error && (
            <div style={{ background: '#fee2e2', color: '#dc2626', padding: '10px 14px', borderRadius: 8, marginBottom: 16, fontSize: 14, fontWeight: 600 }}>
              {error}
            </div>
          )}

          <form onSubmit={submit}>
            {mode === 'register' && (
              <div style={{ marginBottom: 16 }}>
                <label>Username</label>
                <input name="username" type="text" placeholder="e.g. study_cat" value={form.username} onChange={handle} required />
              </div>
            )}
            <div style={{ marginBottom: 16 }}>
              <label>Email</label>
              <input name="email" type="email" placeholder="you@example.com" value={form.email} onChange={handle} required />
            </div>
            <div style={{ marginBottom: 24 }}>
              <label>Password</label>
              <input name="password" type="password" placeholder="••••••••" value={form.password} onChange={handle} required />
            </div>
            <button className="btn-primary" type="submit" disabled={loading} style={{ width: '100%', padding: '12px', fontSize: 16 }}>
              {loading ? '...' : mode === 'login' ? '🐾 Sign In' : '🐾 Create Account'}
            </button>
          </form>
        </div>
      </div>
      <Footer />
    </div>
  );
}
