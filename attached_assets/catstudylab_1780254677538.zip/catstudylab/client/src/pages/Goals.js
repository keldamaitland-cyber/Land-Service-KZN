import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';

export default function Goals() {
  const { authFetch } = useAuth();
  const [goals, setGoals] = useState([]);
  const [form, setForm] = useState({ text: '', targetDate: '' });
  const [showForm, setShowForm] = useState(false);

  const load = () => authFetch('/api/goals').then(r => r.json()).then(setGoals).catch(() => {});
  useEffect(() => { load(); }, []);

  const create = async e => {
    e.preventDefault();
    await authFetch('/api/goals', { method: 'POST', body: JSON.stringify(form) });
    setForm({ text: '', targetDate: '' }); setShowForm(false); load();
  };

  const toggle = async (g) => {
    await authFetch(`/api/goals/${g.id}`, { method: 'PATCH', body: JSON.stringify({ completed: !g.completed }) });
    load();
  };

  const del = async (id) => {
    await authFetch(`/api/goals/${id}`, { method: 'DELETE' }); load();
  };

  const pending = goals.filter(g => !g.completed);
  const done = goals.filter(g => g.completed);

  return (
    <div style={{ padding: 24, maxWidth: 700, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: '#5b21b6' }}>🎯 Study Goals</h1>
          <p style={{ color: '#9ca3af', fontSize: 14, marginTop: 2 }}>{done.length}/{goals.length} completed</p>
        </div>
        <button className="btn-primary" onClick={() => setShowForm(true)}>+ New Goal</button>
      </div>

      {/* Progress bar */}
      {goals.length > 0 && (
        <div style={{ marginBottom: 24, background: '#f3f4f6', borderRadius: 100, height: 10, overflow: 'hidden' }}>
          <div style={{ width: `${(done.length / goals.length) * 100}%`, background: 'linear-gradient(90deg, #7c3aed, #ec4899)', height: '100%', borderRadius: 100, transition: 'width 0.4s' }} />
        </div>
      )}

      {goals.length === 0 && (
        <div className="empty-state"><span className="emoji">🎯</span><h3>No goals yet</h3><p>Set your first study goal!</p></div>
      )}

      {/* Pending */}
      {pending.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <h2 style={{ fontSize: 15, fontWeight: 700, color: '#6b7280', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 1 }}>In Progress</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {pending.map(g => <GoalItem key={g.id} g={g} toggle={toggle} del={del} />)}
          </div>
        </div>
      )}

      {/* Done */}
      {done.length > 0 && (
        <div>
          <h2 style={{ fontSize: 15, fontWeight: 700, color: '#10b981', marginBottom: 10, textTransform: 'uppercase', letterSpacing: 1 }}>✅ Completed</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {done.map(g => <GoalItem key={g.id} g={g} toggle={toggle} del={del} />)}
          </div>
        </div>
      )}

      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h2>🎯 New Study Goal</h2>
            <form onSubmit={create}>
              <div style={{ marginBottom: 14 }}>
                <label>Goal</label>
                <input type="text" value={form.text} onChange={e => setForm(f => ({ ...f, text: e.target.value }))} placeholder="e.g. Finish Chapter 5 revision" required />
              </div>
              <div style={{ marginBottom: 20 }}>
                <label>Target Date (optional)</label>
                <input type="date" value={form.targetDate} onChange={e => setForm(f => ({ ...f, targetDate: e.target.value }))} />
              </div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button className="btn-primary" type="submit">Add Goal</button>
                <button className="btn-secondary" type="button" onClick={() => setShowForm(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function GoalItem({ g, toggle, del }) {
  return (
    <div className="card" style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, opacity: g.completed ? 0.7 : 1 }}>
      <button onClick={() => toggle(g)} style={{
        width: 24, height: 24, borderRadius: '50%', border: `2px solid ${g.completed ? '#10b981' : '#a78bfa'}`,
        background: g.completed ? '#10b981' : 'white', color: 'white', fontWeight: 700, fontSize: 14, flexShrink: 0
      }}>{g.completed ? '✓' : ''}</button>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 700, color: '#1e1b4b', textDecoration: g.completed ? 'line-through' : 'none' }}>{g.text}</div>
        {g.targetDate && <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 2 }}>📅 {new Date(g.targetDate + 'T00:00:00').toLocaleDateString()}</div>}
      </div>
      <button className="btn-danger" onClick={() => del(g.id)}>🗑</button>
    </div>
  );
}
