import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import Flashcards from './pages/Flashcards';
import Timer from './pages/Timer';
import Notes from './pages/Notes';
import Goals from './pages/Goals';
import Footer from './components/Footer';

const TABS = [
  { id: 'dashboard', label: 'Dashboard', emoji: '🏠' },
  { id: 'flashcards', label: 'Flashcards', emoji: '🃏' },
  { id: 'timer', label: 'Timer', emoji: '⏱️' },
  { id: 'notes', label: 'Notes', emoji: '📝' },
  { id: 'goals', label: 'Goals', emoji: '🎯' },
];

function MainApp() {
  const { user, loading, logout } = useAuth();
  const [tab, setTab] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16 }}>
        <div style={{ fontSize: 64 }}>🐱</div>
        <p style={{ color: '#7c3aed', fontWeight: 700, fontSize: 18 }}>Loading Cat Study Lab...</p>
      </div>
    );
  }

  if (!user) return <AuthPage />;

  const renderPage = () => {
    switch (tab) {
      case 'flashcards': return <Flashcards />;
      case 'timer': return <Timer />;
      case 'notes': return <Notes />;
      case 'goals': return <Goals />;
      default: return <Dashboard setTab={setTab} />;
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#f5f3ff' }}>
      {/* Header */}
      <header style={{
        background: 'white',
        borderBottom: '1.5px solid #e9d5ff',
        boxShadow: '0 2px 12px rgba(124,58,237,0.07)',
        position: 'sticky', top: 0, zIndex: 100
      }}>
        <div style={{ maxWidth: 1100, margin: '0 auto', padding: '0 20px', display: 'flex', alignItems: 'center', height: 60 }}>
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginRight: 32 }}>
            <span style={{ fontSize: 28 }}>🐱</span>
            <span style={{ fontWeight: 800, fontSize: 18, color: '#5b21b6' }}>Cat Study Lab</span>
          </div>

          {/* Desktop Nav */}
          <nav style={{ display: 'flex', gap: 4, flex: 1 }}>
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                padding: '7px 14px', borderRadius: 8, border: 'none', fontWeight: 700, fontSize: 14,
                background: tab === t.id ? '#f5f3ff' : 'transparent',
                color: tab === t.id ? '#7c3aed' : '#6b7280',
                borderBottom: tab === t.id ? '2px solid #7c3aed' : '2px solid transparent',
                transition: 'all 0.15s'
              }}>
                <span style={{ marginRight: 5 }}>{t.emoji}</span>{t.label}
              </button>
            ))}
          </nav>

          {/* User */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginLeft: 'auto' }}>
            <span style={{ fontWeight: 700, color: '#5b21b6', fontSize: 14 }}>👤 {user.username}</span>
            <button onClick={logout} style={{
              padding: '6px 14px', borderRadius: 8, border: '1.5px solid #e9d5ff',
              background: 'white', color: '#6b7280', fontWeight: 700, fontSize: 13
            }}>Sign Out</button>
          </div>
        </div>
      </header>

      {/* Content */}
      <main style={{ flex: 1 }}>
        {renderPage()}
      </main>

      {/* Footer - on every tab */}
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
